/*
# Laachi Live — Posts, Likes, Comments, and Gifts tables

1. New Tables
- `posts`: User-generated posts (photos/text) in rooms or on the feed.
  - `id` (uuid, primary key)
  - `user_id` (integer, references users.laachi_id) — post author
  - `room_id` (uuid, references rooms, nullable) — if posted inside a room
  - `content` (text) — text body of the post
  - `image_url` (text, nullable) — optional image
  - `created_at` (timestamptz)
- `likes`: Likes on posts, one per user per post.
  - `id` (uuid, primary key)
  - `post_id` (uuid, references posts, cascade delete)
  - `user_id` (integer, references users.laachi_id)
  - `created_at` (timestamptz)
  - Unique constraint on (post_id, user_id)
- `comments`: Comments on posts.
  - `id` (uuid, primary key)
  - `post_id` (uuid, references posts, cascade delete)
  - `user_id` (integer, references users.laachi_id)
  - `content` (text) — comment text
  - `created_at` (timestamptz)
- `gifts`: Virtual gifts sent between users.
  - `id` (uuid, primary key)
  - `sender_id` (integer, references users.laachi_id) — who sent the gift
  - `receiver_id` (integer, references users.laachi_id) — who received the gift
  - `gift_type` (text) — type of gift (e.g. 'rose', 'star', 'crown')
  - `amount` (numeric, default 1) — quantity / value
  - `created_at` (timestamptz)

2. Security (RLS)
- Enable RLS on all four tables.
- Posts: authenticated users can SELECT all posts, INSERT/UPDATE/DELETE only their own.
- Likes: authenticated users can SELECT all likes, INSERT/DELETE only their own likes.
- Comments: authenticated users can SELECT all comments, INSERT/DELETE only their own comments.
- Gifts: authenticated users can SELECT gifts they sent or received, INSERT only as sender.
*/

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  room_id uuid REFERENCES rooms(id) ON DELETE CASCADE,
  content text NOT NULL DEFAULT '',
  image_url text,
  created_at timestamptz DEFAULT now()
);

-- Likes table
CREATE TABLE IF NOT EXISTS likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE,
  user_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE,
  user_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Gifts table
CREATE TABLE IF NOT EXISTS gifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  receiver_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  gift_type text NOT NULL DEFAULT 'rose',
  amount numeric(12,2) DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE gifts ENABLE ROW LEVEL SECURITY;

-- Posts policies
DROP POLICY IF EXISTS "select_all_posts" ON posts;
CREATE POLICY "select_all_posts" ON posts
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_own_post" ON posts;
CREATE POLICY "insert_own_post" ON posts
  FOR INSERT TO authenticated
  WITH CHECK (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "update_own_post" ON posts;
CREATE POLICY "update_own_post" ON posts
  FOR UPDATE TO authenticated
  USING (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()))
  WITH CHECK (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "delete_own_post" ON posts;
CREATE POLICY "delete_own_post" ON posts
  FOR DELETE TO authenticated
  USING (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

-- Likes policies
DROP POLICY IF EXISTS "select_all_likes" ON likes;
CREATE POLICY "select_all_likes" ON likes
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_own_like" ON likes;
CREATE POLICY "insert_own_like" ON likes
  FOR INSERT TO authenticated
  WITH CHECK (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "delete_own_like" ON likes;
CREATE POLICY "delete_own_like" ON likes
  FOR DELETE TO authenticated
  USING (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

-- Comments policies
DROP POLICY IF EXISTS "select_all_comments" ON comments;
CREATE POLICY "select_all_comments" ON comments
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_own_comment" ON comments;
CREATE POLICY "insert_own_comment" ON comments
  FOR INSERT TO authenticated
  WITH CHECK (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "delete_own_comment" ON comments;
CREATE POLICY "delete_own_comment" ON comments
  FOR DELETE TO authenticated
  USING (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

-- Gifts policies
DROP POLICY IF EXISTS "select_own_gifts" ON gifts;
CREATE POLICY "select_own_gifts" ON gifts
  FOR SELECT TO authenticated
  USING (
    sender_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid())
    OR receiver_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid())
  );

DROP POLICY IF EXISTS "insert_own_gift" ON gifts;
CREATE POLICY "insert_own_gift" ON gifts
  FOR INSERT TO authenticated
  WITH CHECK (sender_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));
