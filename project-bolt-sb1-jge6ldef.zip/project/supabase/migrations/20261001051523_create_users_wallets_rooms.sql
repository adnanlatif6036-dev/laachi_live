/*
# Laachi Live — Users, Wallets, and Rooms tables

1. New Tables
- `users`: Stores Laachi Live user profiles linked to auth.
  - `laachi_id` (integer, primary key, auto-increment starting from 1001)
  - `auth_id` (uuid, unique, references auth.users)
  - `name` (text), `email` (text), `photo_url` (text)
  - `wallet_balance` (numeric, default 0)
  - `created_at` (timestamptz)
- `rooms`: Game/room sessions with room_code, host_id, status, created_at
- `room_participants`: Junction table for room membership
- `wallet_transactions`: Transaction history

2. Sequence: users_laachi_id_seq starts at 1001

3. Security: RLS on all tables, authenticated-only, ownership-scoped.
*/

CREATE SEQUENCE IF NOT EXISTS users_laachi_id_seq START 1001;

CREATE TABLE IF NOT EXISTS users (
  laachi_id integer PRIMARY KEY DEFAULT nextval('users_laachi_id_seq'),
  auth_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  name text,
  email text,
  photo_url text,
  wallet_balance numeric(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER SEQUENCE users_laachi_id_seq OWNED BY users.laachi_id;

CREATE TABLE IF NOT EXISTS rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_code text UNIQUE NOT NULL,
  host_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  status text DEFAULT 'waiting',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS room_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid REFERENCES rooms(id) ON DELETE CASCADE,
  user_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  joined_at timestamptz DEFAULT now(),
  UNIQUE(room_id, user_id)
);

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id integer REFERENCES users(laachi_id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL,
  type text NOT NULL DEFAULT 'credit',
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON users;
CREATE POLICY "select_own_profile" ON users
  FOR SELECT TO authenticated
  USING (auth_id = auth.uid());

DROP POLICY IF EXISTS "insert_own_profile" ON users;
CREATE POLICY "insert_own_profile" ON users
  FOR INSERT TO authenticated
  WITH CHECK (auth_id = auth.uid());

DROP POLICY IF EXISTS "update_own_profile" ON users;
CREATE POLICY "update_own_profile" ON users
  FOR UPDATE TO authenticated
  USING (auth_id = auth.uid())
  WITH CHECK (auth_id = auth.uid());

DROP POLICY IF EXISTS "select_rooms" ON rooms;
CREATE POLICY "select_rooms" ON rooms
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_own_room" ON rooms;
CREATE POLICY "insert_own_room" ON rooms
  FOR INSERT TO authenticated
  WITH CHECK (host_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "update_own_room" ON rooms;
CREATE POLICY "update_own_room" ON rooms
  FOR UPDATE TO authenticated
  USING (host_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "select_room_participants" ON room_participants;
CREATE POLICY "select_room_participants" ON room_participants
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "insert_own_participation" ON room_participants;
CREATE POLICY "insert_own_participation" ON room_participants
  FOR INSERT TO authenticated
  WITH CHECK (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "select_own_transactions" ON wallet_transactions;
CREATE POLICY "select_own_transactions" ON wallet_transactions
  FOR SELECT TO authenticated
  USING (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));

DROP POLICY IF EXISTS "insert_own_transactions" ON wallet_transactions;
CREATE POLICY "insert_own_transactions" ON wallet_transactions
  FOR INSERT TO authenticated
  WITH CHECK (user_id IN (SELECT laachi_id FROM users WHERE auth_id = auth.uid()));
