export interface LaachiUser {
  laachi_id: number
  auth_id: string
  name: string
  email: string
  photo_url: string | null
  wallet_balance: number
  created_at: string
}

export interface Room {
  id: string
  room_code: string
  host_id: number
  status: string
  created_at: string
}

export interface RoomParticipant {
  id: string
  room_id: string
  user_id: number
  joined_at: string
}

export interface WalletTransaction {
  id: string
  user_id: number
  amount: number
  type: string
  description: string
  created_at: string
}

export interface Post {
  id: string
  user_id: number
  room_id: string | null
  content: string
  image_url: string | null
  created_at: string
}

export interface Like {
  id: string
  post_id: string
  user_id: number
  created_at: string
}

export interface Comment {
  id: string
  post_id: string
  user_id: number
  content: string
  created_at: string
}

export interface Gift {
  id: string
  sender_id: number
  receiver_id: number
  gift_type: string
  amount: number
  created_at: string
}
