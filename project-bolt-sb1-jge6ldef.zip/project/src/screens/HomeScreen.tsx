import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { LogOut, PlusCircle, LogIn, Wallet, ChevronRight } from 'lucide-react'
import { CreateRoomModal } from '../components/CreateRoomModal'
import { JoinRoomModal } from '../components/JoinRoomModal'
import { WalletModal } from '../components/WalletModal'

export function HomeScreen() {
  const { user, signOut } = useAuth()
  const [modal, setModal] = useState<'none' | 'create' | 'join' | 'wallet'>('none')

  if (!user) return null

  return (
    <div className="home-page">
      {/* Header */}
      <div className="home-header fade-in">
        <div className="home-header-brand">
          <img src="/logo.svg" alt="Laachi Live" className="app-logo-sm" />
          <span>Laachi Live</span>
        </div>
      </div>

      {/* Profile Card */}
      <div className="profile-card fade-in delay-1">
        {user.photo_url ? (
          <img className="profile-photo" src={user.photo_url} alt={user.name} />
        ) : (
          <div className="profile-photo-placeholder">
            {user.name?.charAt(0)?.toUpperCase() || 'L'}
          </div>
        )}
        <h2 className="profile-name">{user.name}</h2>
        <div className="profile-id-badge">ID: {user.laachi_id}</div>
      </div>

      {/* Action Buttons */}
      <div className="action-buttons">
        <button
          className="action-btn action-btn-primary fade-in delay-2"
          onClick={() => setModal('create')}
        >
          <div className="action-btn-icon">
            <PlusCircle size={24} />
          </div>
          <span className="action-btn-text">Create Room</span>
          <ChevronRight size={20} className="action-btn-arrow" />
        </button>

        <button
          className="action-btn action-btn-secondary fade-in delay-3"
          onClick={() => setModal('join')}
        >
          <div className="action-btn-icon">
            <LogIn size={24} />
          </div>
          <span className="action-btn-text">Join Room</span>
          <ChevronRight size={20} className="action-btn-arrow" />
        </button>

        <button
          className="action-btn action-btn-tertiary fade-in delay-4"
          onClick={() => setModal('wallet')}
        >
          <div className="action-btn-icon">
            <Wallet size={24} />
          </div>
          <span className="action-btn-text">My Wallet</span>
          <ChevronRight size={20} className="action-btn-arrow" />
        </button>
      </div>

      {/* Logout */}
      <div className="logout-btn">
        <button className="logout-link" onClick={signOut}>
          <LogOut size={16} />
          Sign Out
        </button>
      </div>

      {/* Modals */}
      {modal === 'create' && <CreateRoomModal onClose={() => setModal('none')} />}
      {modal === 'join' && <JoinRoomModal onClose={() => setModal('none')} />}
      {modal === 'wallet' && <WalletModal onClose={() => setModal('none')} />}
    </div>
  )
}
