import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { supabase } from '../lib/supabase'
import type { LaachiUser } from '../types'

interface AuthContextValue {
  user: LaachiUser | null
  loading: boolean
  signInWithGoogle: () => Promise<void>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<LaachiUser | null>(null)
  const [loading, setLoading] = useState(true)

  async function fetchProfile(authId: string): Promise<LaachiUser | null> {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('auth_id', authId)
      .maybeSingle()

    if (error) {
      console.error('Error fetching profile:', error)
      return null
    }
    return data as LaachiUser | null
  }

  async function createProfileIfMissing(
    authId: string,
    name: string,
    email: string,
    photoUrl: string | null
  ): Promise<LaachiUser | null> {
    const existing = await fetchProfile(authId)
    if (existing) return existing

    const { data, error } = await supabase
      .from('users')
      .insert({
        auth_id: authId,
        name,
        email,
        photo_url: photoUrl,
      })
      .select('*')
      .single()

    if (error) {
      console.error('Error creating profile:', error)
      return null
    }
    return data as LaachiUser
  }

  useEffect(() => {
    let mounted = true

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return
      if (session?.user) {
        const authId = session.user.id
        const name = session.user.user_metadata?.full_name || 'Laachi User'
        const email = session.user.email || ''
        const photoUrl = session.user.user_metadata?.avatar_url || null

        createProfileIfMissing(authId, name, email, photoUrl).then((profile) => {
          if (!mounted) return
          setUser(profile)
          setLoading(false)
        })
      } else {
        setLoading(false)
      }
    })

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      ;(async () => {
        if (session?.user) {
          const authId = session.user.id
          const name = session.user.user_metadata?.full_name || 'Laachi User'
          const email = session.user.email || ''
          const photoUrl = session.user.user_metadata?.avatar_url || null

          const profile = await createProfileIfMissing(authId, name, email, photoUrl)
          if (!mounted) return
          setUser(profile)
        } else {
          if (!mounted) return
          setUser(null)
        }
      })()
    })

    return () => {
      mounted = false
      listener.subscription.unsubscribe()
    }
  }, [])

  async function signInWithGoogle() {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin,
      },
    })
    if (error) {
      console.error('Google sign-in error:', error)
    }
  }

  async function signOut() {
    await supabase.auth.signOut()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
