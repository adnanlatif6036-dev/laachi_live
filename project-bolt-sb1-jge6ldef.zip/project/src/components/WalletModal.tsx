import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { X, Wallet, ArrowDownCircle, ArrowUpCircle, Inbox } from 'lucide-react'
import type { WalletTransaction } from '../types'

export function WalletModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth()
  const [transactions, setTransactions] = useState<WalletTransaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadTransactions() {
      if (!user) return
      const { data, error } = await supabase
        .from('wallet_transactions')
        .select('*')
        .eq('user_id', user.laachi_id)
        .order('created_at', { ascending: false })
        .limit(20)

      if (!error && data) {
        setTransactions(data as WalletTransaction[])
      }
      setLoading(false)
    }
    loadTransactions()
  }, [user])

  if (!user) return null

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="action-btn-icon" style={{ background: 'var(--pink-100)', color: 'var(--pink-500)' }}>
            <Wallet size={24} />
          </div>
          <button className="modal-close" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <h2 className="modal-title">My Wallet</h2>

        <div className="info-row">
          <span className="info-row-label">Available Balance</span>
          <span className="info-row-value">₹{Number(user.wallet_balance).toFixed(2)}</span>
        </div>

        <div style={{ width: '100%' }}>
          <h3 style={{ fontSize: 16, fontWeight: 600, color: 'var(--neutral-800)', marginBottom: 12 }}>
            Recent Transactions
          </h3>

          {loading ? (
            <p style={{ color: 'var(--neutral-400)', textAlign: 'center', padding: 20 }}>
              Loading...
            </p>
          ) : transactions.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">
                <Inbox size={28} />
              </div>
              <p className="empty-state-text">No transactions yet</p>
            </div>
          ) : (
            <div className="tx-list">
              {transactions.map((tx) => (
                <div key={tx.id} className="tx-item">
                  <div className={`tx-icon ${tx.type === 'credit' ? 'tx-icon-credit' : 'tx-icon-debit'}`}>
                    {tx.type === 'credit' ? <ArrowDownCircle size={22} /> : <ArrowUpCircle size={22} />}
                  </div>
                  <div className="tx-details">
                    <span className="tx-desc">{tx.description || tx.type}</span>
                    <span className="tx-date">
                      {new Date(tx.created_at).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>
                  <span className={`tx-amount ${tx.type === 'credit' ? 'tx-amount-credit' : 'tx-amount-debit'}`}>
                    {tx.type === 'credit' ? '+' : '-'}₹{Math.abs(Number(tx.amount)).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
