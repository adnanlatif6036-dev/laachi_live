export function LoadingScreen() {
  return (
    <div className="loading-screen">
      <img src="/logo.svg" alt="Laachi Live" className="app-logo scale-in" />
      <div className="loading-spinner" />
      <p className="loading-text">Loading...</p>
    </div>
  )
}
