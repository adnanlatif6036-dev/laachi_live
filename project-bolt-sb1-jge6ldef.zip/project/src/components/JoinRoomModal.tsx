import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { X, LogIn, Users } from 'lucide-react'
import type { Room } from '../types'

export function JoinRoomModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth()
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [joinedRoom, setJoinedRoom] = useState<Room | null>(null)

  async function handleJoin() {
    if (!user) return
    if (code.trim().length < 6) {
      setError('Please enter a 6-character room code.')
      return
    }

    setLoading(true)
    setError(null)

    const { data: room, error: findError } = await supabase
      .from('rooms')
      .select('*')
      .eq('room_code', code.trim().toUpperCase())
      .maybeSingle()

    if (findError || !room) {
      setError('Room not found. Check the code and try again.')
      setLoading(false)
      return
    }

    const { data: existing } = await supabase
      .from('room_participants')
      .select('id')
      .eq('room_id', room.id)
      .eq('user_id', user.laachi_id)
      .maybeSingle()

    if (!existing) {
      await supabase.from('room_participants').insert({
        room_id: room.id,
        user_id: user.laachi_id,
      })
    }

    setJoinedRoom(room as Room)
    setLoading(false)
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="action-btn-icon" style={{ background: 'var(--pink-100)', color: 'var(--pink-500)' }}>
            <LogIn size={24} />
          </div>
          <button className="modal-close" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <h2 className="modal-title">Join Room</h2>

        {error && (
          <p style={{ color: 'var(--error)', fontSize: 14, textAlign: 'center' }}>{error}</p>
        )}

        {joinedRoom ? (
          <div className="room-code-display">
            <Users size={28} style={{ color: 'var(--pink-500)' }} />
            <span className="room-code-label">You joined room</span>
            <span className="room-code-value">{joinedRoom.room_code}</span>
            <span className="badge badge-waiting">
              {joinedRoom.status === 'waiting' ? 'Waiting for players' : joinedRoom.status}
            </span>
          </div>
        ) : (
          <input
            className="form-input"
            placeholder="Enter 6-digit code"
            value={code}
            onChange={(e) => setCode(e.target.value.slice(0, 6))}
            onKeyDown={(e) => e.key === 'Enter' && handleJoin()}
            autoFocus
          />
        )}

        {!joinedRoom && (
          <button className="form-btn" onClick={handleJoin} disabled={loading}>
            {loading ? 'Joining...' : 'Join Room'}
          </button>
        )}
      </div>
    </div>
  )
}
