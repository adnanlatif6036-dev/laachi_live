import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { X, PlusCircle, Copy, Check } from 'lucide-react'

export function CreateRoomModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [roomCode, setRoomCode] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  function generateCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    let code = ''
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)]
    }
    return code
  }

  async function handleCreate() {
    if (!user) return
    setLoading(true)
    setError(null)

    const code = generateCode()

    const { data, error: insertError } = await supabase
      .from('rooms')
      .insert({
        room_code: code,
        host_id: user.laachi_id,
        status: 'waiting',
      })
      .select('*')
      .single()

    if (insertError) {
      setError('Could not create room. Please try again.')
      setLoading(false)
      return
    }

    await supabase.from('room_participants').insert({
      room_id: data.id,
      user_id: user.laachi_id,
    })

    setRoomCode(data.room_code)
    setLoading(false)
  }

  async function handleCopy() {
    if (!roomCode) return
    try {
      await navigator.clipboard.writeText(roomCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // ignore
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div className="action-btn-icon" style={{ background: 'var(--pink-100)', color: 'var(--pink-500)' }}>
            <PlusCircle size={24} />
          </div>
          <button className="modal-close" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <h2 className="modal-title">Create Room</h2>

        {error && (
          <p style={{ color: 'var(--error)', fontSize: 14, textAlign: 'center' }}>{error}</p>
        )}

        {roomCode ? (
          <div className="room-code-display">
            <span className="room-code-label">Share this code with friends</span>
            <span className="room-code-value">{roomCode}</span>
            <button className="room-code-copy" onClick={handleCopy}>
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? 'Copied!' : 'Copy Code'}
            </button>
          </div>
        ) : (
          <p style={{ color: 'var(--neutral-600)', fontSize: 15, textAlign: 'center', lineHeight: 1.5 }}>
            Create a new room and invite your friends to join with the room code.
          </p>
        )}

        <button
          className="form-btn"
          onClick={handleCreate}
          disabled={loading}
        >
          {loading ? 'Creating...' : roomCode ? 'Create Another' : 'Create Room'}
        </button>
      </div>
    </div>
  )
}
